###################
Remaja ID
###################

Remaja ID adalah aplikasi berbasis website yang bertujuan untuk membantu urusan dalam suatu organisasi karang taruna desa.

*******************
Hak akses
*******************

dalam aplikasi ini terdapat 4 hak akses yaitu:

- admin
- bendahara
- petugas
- anggota

**************************
Fitur
**************************

Template home: `Grayscale <https://startbootstrap.com/theme/grayscale>`_

Template dashboard: `SB Admin 2 <https://startbootstrap.com/theme/sb-admin-2>`_

fitur fitur dalam aplikasi ini meliputi:

- Login
1. login (semua hak akses)
2. register (hanya anggota)
3. lupa password (semua hak akses)

- Admin
1. Create user
2. mengirim password baru
3. melihat pengaduan
4. dll

- Bendahara
1. Input kas
2. Input pemasukan + print
3. Input pengeluaran + print

- Petugas
1. Input Kegiatan
2. Input pengumuman
3. Input master unit
4. Input data pinjaman

- Anggota
1. View pengumuman
2. View history kas
3. Input pengaduan

*******************
Creator
*******************

Ahmad Zaeni Mubarok

- Gmail : ahmadzaenimubarok121@gmail.com
- Whatsapp : 081328331831
- Facebook : `AA43000 <https://facebook.com/aa43000>`_

